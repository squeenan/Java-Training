package game;

public class RoomManager {
	public static void main(String[] args) {
		
	}
}
