package fixtures;

public class Room {

}
