package main;

import java.util.Scanner;

public class Converter {
	
	int cups = 0;
	int teaspoons = 0;
	int miles = 0;
	int kilos = 0;
	int pints = 0;
	int gallons = 0;
	int celsius = 0;
	int fahrenheit = 0;
	double result = 0;
	
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);		
		Converter convert = new Converter();				
		int menuSelection = 0;
		
		while(menuSelection != 5) {
			
			System.out.println ("Please select an option: "
					+ "\n1. Cups to Teaspoons \n2. Miles to Kilometers"
					+ "\n3. Pints to Gallons \n4. Celsius to Fahrenheit"
					+ "\n5. Quit\n");
			
			menuSelection = input.nextInt();
			
			switch (menuSelection) {
			case 1: 
				System.out.println("You have chosen to convert Cups"
								 + " to Teaspoons\nYou can also choose"
								 + " to convert Teaspoons to Cups\nPlease "
								 + "select an option:\n1. Cups to Teaspoons "
								 + "\n2. Teaspoons to Cups\n");
				
				menuSelection = input.nextInt();
				
				if (menuSelection == 1) {
					System.out.println("Please enter the number of Cups:");
					convert.cups = input.nextInt();
					convert.result = cupsToTeaspoons(convert.cups);
					System.out.println(convert.cups + " Cups = " + convert.result + " Teaspoons\n");
				}else if(menuSelection == 2) {
					System.out.println("Please enter the value of Teaspoons");
					convert.teaspoons = input.nextInt();
					convert.result = teaspoonsToCups(convert.teaspoons);
					System.out.println(convert.teaspoons + " Teaspoons = " + convert.result + " Cups\n");
				}
				break;
			case 2:
				System.out.println("You have chosen to convert Miles to "
								 + "Kilometers\nYou can also choose to "
								 + "convert Kilometers to Miles\nPlease "
								 + "select an option:\n1. Miles to Kilometers"
								 + "\n2. Kilometers to Miles\n");
				
				menuSelection = input.nextInt();
				
				if (menuSelection == 1) {
					System.out.println("Please enter the number of Miles:");
					convert.miles = input.nextInt();
					convert.result = milesToKilos(convert.miles);
					System.out.println(convert.miles + " Miles = " + convert.result + " Kilometers\n");
				}else if (menuSelection == 2) {
					System.out.println("Please enter the number of Kilometers:");
					convert.kilos = input.nextInt();
					convert.result = kilosToMiles(convert.kilos);
					System.out.println(convert.kilos + " Kilometers = " + convert.result + " Miles\n");
				}				
				break;
			case 3:
				System.out.println("You have chosen to convert Gallons "
								 + "to Pints\nYou can also choose to convert Pints "
								 + "to Gallons\nPlease select an option:\n1. Gallons "
								 + "to Pints\n2. Pints to Gallons\n");
				
				menuSelection = input.nextInt();
				
				if (menuSelection == 1) {
					System.out.println("Please enter the number of Gallons");
					convert.gallons = input.nextInt();
					convert.result = gallonsToPints(convert.gallons);
					System.out.println(convert.gallons + " Gallons = " + convert.result + " Pints\n");
				}else if (menuSelection == 2) {
					System.out.println("Please enter the number of Pints:");
					convert.pints = input.nextInt();
					convert.result = pintsToGallons(convert.pints);
					System.out.println(convert.pints + " Pints = " + convert.result + " Gallons\n");
				}
				
				break;
			case 4:
				System.out.println("You have chosen to convert Celcius "
								 + "to Fahrenheit\nYou can also choose to convert "
								 + "Fahrenheit to Celcius\nPlease select an option:"
								 + "\n1. Celcius to Fahrenheit\n2. Fahrenheit to Celcius\n");
				
				menuSelection = input.nextInt();
				
				if (menuSelection == 1) {
					System.out.println("Please enter the degrees of Celsius:");
					convert.celsius = input.nextInt();
					convert.result = celsiusToFahrenheit(convert.celsius);
					System.out.println(convert.celsius + " Celsius = " + convert.result + " Fahrenheit\n");
				}else if (menuSelection == 2) {
					System.out.println("Please enter the degrees of Fahrenheit:");
					convert.fahrenheit = input.nextInt();
					convert.result = fahrenheitToCelsius(convert.fahrenheit);
					System.out.println(convert.fahrenheit + " Fahrenheit = " + convert.result + " Celsius\n");
				}
				break;
			case 5:
				System.out.println("Thank you for using my Unit Converter");
				break;
				
			}
		}input.close();
		
	}

	public static double fahrenheitToCelsius(int fahrenheit) {
		double result = (double) ((fahrenheit -32) * 5/9);
		return result;
	}

	public static double celsiusToFahrenheit(int celsius) {
		double result = (double) ((celsius * 9/5) + 32); 
		return result;
	}

	public static double pintsToGallons(int pints) {
		double result = (double) pints / 8;
		return result;
	}

	public static double gallonsToPints(int gallons) {
		double result = (double) gallons * 8;
		return result;
	}

	public static double teaspoonsToCups(int teaspoons) {
		double result = (double) teaspoons / 48;
		return result;
	}

	public static double cupsToTeaspoons(int cups) {
		double result = (double) cups * 48;
		return result;
	}
	
	public static double milesToKilos(int miles) {
		double result = (double) miles * 1.609;
		return result;
	}
	
	public static double kilosToMiles(int kilos) {
		double result = (double) kilos / 1.609;
		return result;
	}
}
