package main;

import java.util.Scanner;

public class SwitchStatements {

	public static void main(String[] args) {

		/*
		 * Switch statements allow a variable to be tested for equality against
		 * a list of values
		 */
		Scanner scan = new Scanner(System.in);
		
		System.out.println("What day is it today?");
		String day = scan.nextLine().toLowerCase();
		
		switch (day) {
		case "sunday":
			System.out.println("Woohoo! Today is Sunday!");
			break;			//make sure to have break after each case!
		
		case "monday":
			System.out.println("Woohoo!Today is Monday!");
			break;
			
		case "tuesday":
			System.out.println("Woohoo! Today is Tuesday!");
			break;
			
		case "wednesday":
			System.out.println("Woohoo! Today is Wednesday!");
			break;
			
		case "thursday":
			System.out.println("Woohoo! Today is Thursday!");
			break;
			
		case "friday":
			System.out.println("Woohoo! Today is Friday!");
			break;
			
		case "saturday":
			System.out.println("Woohoo! Today is Saturday!");
			break;
		default:
			System.out.println(day +"!" + " That is not a real day. "
							 + "It should be, but it's not!");
			
		
		
		}	
		scan.close();
	}

}
