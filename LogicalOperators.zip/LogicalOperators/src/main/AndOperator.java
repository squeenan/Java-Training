package main;

import java.util.Random;
import java.util.Scanner;


public class AndOperator {

	public static void main(String[] args) {
				
		/*
		 * Logical Operators are used to connect two or more expressions:
		 * && (and) both conditions must be true
		 * || (or) either condition must be true
		 * ! (not) reverses boolean value of a condition
		 */
		Random random = new Random();
		int temp = random.nextInt(120);
		System.out.println(temp);
		
		if (temp > 100) {
			System.out.println("It is so hot outside, you could "
							 + "fry an egg on your car!");
		}else if (temp >= 80 && temp <= 100) {
			System.out.println("It is warm outside!");
		}else if (temp <= 79 && temp >= 50) {
			System.out.println("It is pretty frickin nice outside!");
		}else {
			System.out.println("It is frickin cold outside!");
		}
		
	}
	
	
	


}
