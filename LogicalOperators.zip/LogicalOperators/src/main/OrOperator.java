package main;

import java.util.Scanner;

public class OrOperator {

	public static void main(String[] args) {
		/*
		 * Logical Operators are used to connect two or more expressions:
		 * && (and) both conditions must be true
		 * || (or) either condition must be true
		 * ! (not) reverses boolean value of a condition
		 */
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("You are playing a game! Press q or Q to QUIT");
		String input = scan.next();
		
		if (input.equals("q") || input.equals("Q")) {
			System.out.println("You quit the game!");
		}else {
			System.out.println("You are still playing the game 'PEW, PEW'");
		}
		
		
	}
	
}
