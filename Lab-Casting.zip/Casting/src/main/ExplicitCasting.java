package main;

public class ExplicitCasting {

	public static void main(String[] args) {

		double d = 10.6;
		int n = (int) d;	//Casting is happening here
		
		System.out.println(d);
		System.out.println(n);
		//The .60 is lost in conversion
	}

}
