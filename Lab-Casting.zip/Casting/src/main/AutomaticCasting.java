package main;

public class AutomaticCasting {

	public static void main(String[] args) {

		int n = 10;
		double d = n;	//This is now converted from an int to a double
		
		System.out.println(n);
		System.out.println(d);
	}

	
}
