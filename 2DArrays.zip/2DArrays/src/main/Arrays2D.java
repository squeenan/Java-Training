package main;

public class Arrays2D {

	public static void main(String[] args) {

		//2D Array is an array of arrays
		String[][] cars = new String [3][3];	//This says array will be a 3 x 3 
		
// Note: Just another way to write the same 2D array with a 3 x 3
// 		String[][] cars = {{"Camaro", "Corvette", "Sliverado"}, 
//						   {"Mustang", "Expedition", "Accord"},
// 				 		   {"F-150", "Ranger", "Prius"}};

		
		cars[0][0] = "Camaro";
		cars[0][1] = "Corvette";
		cars[0][2] = "Sliverado";
		
		cars[1][0] = "Mustang";
		cars[1][1] = "Expedition";
		cars[1][2] = "Accord";
		
		cars[2][0] = "F-150";
		cars[2][1] = "Ranger";
		cars[2][2] = "Prius";
		
		for(int i = 0; i < cars.length; i++) {
			System.out.println();
			for(int j = 0; j < cars[i].length; j++) {
				System.out.println(cars[i][j] +" ");
			}
		}
		
		
		
		
	}

}
