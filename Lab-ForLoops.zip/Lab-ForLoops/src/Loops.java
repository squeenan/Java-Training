
public class Loops {
	public static void main(String[] args) {
		
		//create a simple for-loop that prints the numbers 1 to 10
		for (int i = 1; i <= 10; i++) {
			System.out.println(i);
		}
	}
}
