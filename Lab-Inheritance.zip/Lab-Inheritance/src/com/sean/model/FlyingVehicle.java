package com.sean.model;

public class FlyingVehicle extends Vehicle {

	private short wings;
	private Engine engine;
	
	//this no-args constructor was added instead of the super() in Airplane class
	public FlyingVehicle() {
		
	}
	
	public FlyingVehicle(short wings, Engine engine) {
		this.wings = wings;
		this.engine = engine;
	}
	
	//getters and setters
	public short getWings() {
		return this.wings;
	}
	
	public void setWings() {
		this.wings = wings;
	}
	
	public Engine getEngine() {
		return this.engine;
	}
	
	public void setEngine(Engine engine) {
		this.engine = engine;
	}
	
	public void fly() {
		System.out.println("FlyingVehicle is flying...");
	}
	
	public void refuel() {
		System.out.println("Flying vehicle is refueling");
	}
	
	public void liftOff() {
		System.out.println("FlyingVehicle is lifting off...");
	}
	
	public void land() {
		System.out.println("FlyingVehicle is landing...");
	}
}
