package main;

public class WrapperClass {

	public static void main(String[] args) {

		/*
		 * Wrapper Class provides a way to use primitive data types
		 * as reference data types. Reference data types contain useful 
		 * methods and can be used with collections (ex:ArrayList)
		 */
		
		/*primitive		wrapper
		 * -------		------
		 * boolean		Boolean
		 * char			Character
		 * int			Integer
		 * double		Double
		 */
		
		/*
		 * Autoboxing is the automatic conversion that the Java compiler
		 * makes between the primitive types and their corresponding
		 * object wrapper class
		 * 
		 * Unboxing is the reverse of autoboxing. Automatic conversion of 
		 * wrapper class to primitive
		 */
		
		//autoboxing - converting to wrapper class
		Boolean a = true;		
		Character b = '@';
		Integer c = 123;
		Double d = 3.14;
		String e = "Sean";
		
		//unboxing - converting to primitive
		if (a == true) {
			System.out.println("This is: " +a);
		}
	
	}

}
