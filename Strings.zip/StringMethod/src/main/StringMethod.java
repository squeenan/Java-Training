package main;

public class StringMethod {

	public static void main(String[] args) {

		/*String is a reference data type that can store one
		*or more characters. Reference data types have access
		*to useful methods.
		*/
		
		String name = "Sean";
		boolean result = name.equalsIgnoreCase("sean");	//ignores any case sensitive
		System.out.println(result);
		
		int output = name.length();	//finds the length of 'name'
		System.out.println(output);
		
		char one = name.charAt(0);	//finds the character at index 0 of name
		System.out.println(one);
		
		int two = name.indexOf("n");	//finds the index of where 'n' is
		System.out.println(two);
		
		boolean three = name.isEmpty();	//true or false is variable 'name' is empty
		System.out.println(three);
		
		String four = name.toUpperCase();	//changes characters to upper case
		System.out.println(four);
		
		String five = name.toLowerCase();	//changes characters to lower case
		System.out.println(five);
		
		String six = name.trim();	//trims the white space 
		System.out.println(six);
		
		String seven = name.replace('S', 'd');	//replaces all S with d
		System.out.println(seven);
		
		
		
		
	}

}
