package main;

import java.util.Scanner;

public class WhileLoops {

	public static void main(String[] args) {

		/*
		 * While loops execute a block of code as long as 
		 * it's condition remains true
		 */
		
		Scanner scan = new Scanner(System.in);
		String name = " ";
		
		while (name.isBlank()) {
			System.out.print("Enter your name: ");
			name = scan.nextLine();			
		}
		System.out.println("Hello " +name+ "! Nice to meet you!!");
	}

}
