
public class MyClass {
	public static void main(String[] args) {
		System.out.println("Sean Queenan");
	}
}
