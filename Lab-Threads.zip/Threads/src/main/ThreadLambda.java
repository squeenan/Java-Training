package main;

public class ThreadLambda {

	public static void main(String[] args) {
		Thread willRun = new Thread(() -> {
			System.out.println("Running!");
		});
		willRun.start();
	}
	
}
