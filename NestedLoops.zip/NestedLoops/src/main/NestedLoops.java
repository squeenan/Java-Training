package main;

import java.util.Scanner;

public class NestedLoops {

	public static void main(String[] args) {

		//nested loops are a loop inside of another loop
		
		Scanner scan = new Scanner(System.in);
		
		int rows;
		int columns;
		String symbol = " ";
		
		System.out.println("Enter # of rows: ");
		rows = scan.nextInt();
		
		System.out.println("Enter # of columns: ");
		columns = scan.nextInt();
		
		System.out.println("Enter symbol to use: ");
		symbol = scan.next();
		
		for (int i = 1; i <= rows; i++) {		//this can be made with while loop too
			System.out.println();
			for(int j = 1; j <= columns; j++) {	//it's just a for loop within a for loop
				System.out.print(symbol);
			}
		}
		
	}

}
