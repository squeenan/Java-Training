package main;

import java.util.ArrayList;
import java.util.List;

public class VarArgsExample {

	public static void someMethod(int a, int...manyInts) {
		System.out.println("First argument: " + a);
			System.out.println("Next argument: ");
			for (int i = 0; i < manyInts.length; i++) {
				System.out.println(manyInts[i]);
			}			
	}
	
	public static void main(String[] args) {
		
		VarargsExample.someMethod(1, 3, 4, 5, 6);
		/*
		 * First argument: 1
		 * Next argument:
		 * 3
		 * 4
		 * 5
		 * 6 
		 */
		List<String> names = new ArrayList<>();
		names.add("Alice");
		names.add("Bob");
		names.add("Charlie");
		names.forEach(str -> System.out.println(str));
		
		
	}
}
