package main;

public class TestStack {
	
	public static void main(String[] args) {
		
	Stack stack = new Stack();
	 
	stack.push(1);
	stack.push(2);
	
	int value = stack.pop();
	
	System.out.println(value);
	System.out.println(value);
	}
}
