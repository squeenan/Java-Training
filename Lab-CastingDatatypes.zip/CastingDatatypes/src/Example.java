
public class Example {
	public static void main(String[] args) {
//		initial values
		int i = 200;
		
//		cast to a short
		short s = (short)i;
		System.out.println(s);
		
//		cast to a double
		double d = (double)i;
		System.out.println(d);
		
//		cast to a byte
		byte b = (byte)i;
		System.out.println(b);
		
	}
}
