
public class ExampleOne {
	public static void main(String[] args) {
		boolean on = false;
		
		do {
			
			System.out.println("Inside the do-while loop");
			
		} while (on);
	}
}