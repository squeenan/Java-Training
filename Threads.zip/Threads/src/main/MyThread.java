package main;

public class MyThread extends Thread {

	@Override
	public void run() {
		System.out.println("Inside the MyThread class");
	}
	
}
