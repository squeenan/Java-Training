package main;

public class ThreadDemo {

	public static void main(String[] args) {
		
		Thread myRunnable = new Thread(new MyRunnable());
		Thread myThread = new MyThread();
		myRunnable.start();
		myThread.start();
		
	}

}
