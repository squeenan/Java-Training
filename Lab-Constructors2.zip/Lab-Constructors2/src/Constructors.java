
public class Constructors {

	//with int value you must input value in constructor (args) 
	public Constructors(int value) {
		System.out.println(value);
	}	
	
	//default no-args constructor
	public Constructors() {
		System.out.println("Default constructor ran");
	}	
	
	public static void main(String[] args) {
		
		//create instances here
		//with int value in public constructor we need to fill int value
		Constructors c = new Constructors(1313);
		
		//use the no-arg constructor
		Constructors cNoArg = new Constructors();
		
	}
}
