package com.example.model;

public class ActionFigure extends Doll {

	
	}

	
