package main;

import java.util.Random;

public class RandomNumbers {

	public static void main(String[] args) {
		
		Random random = new Random();
		
//		int x = random.nextInt(6);		//prints out random int limited to 6
//		double y = random.nextDouble();	//prints out random double value
		boolean z = random.nextBoolean();	//prints out random boolean value
		
		System.out.println(z);
		
	}
}
