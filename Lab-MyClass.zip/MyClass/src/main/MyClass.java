package main;

public class MyClass {

	public static void myMethod(String name) {
		System.out.println(name);
	}
	
	public static void main(String[] args) {
		myMethod("Liam");
		myMethod("Jenny");
	}
}
