package main;

public class Arrays {

	public static void main(String[] args) {
		
		//Arrays are used to store multiple values in a single variable
		
		String[] domesticCars = {"Camaro", "Corvette", "Tesla", "Ford"}; //Array of cars
		
//		cars[4] = "Mustang";	//You cannot add to an existing array but can write over it
		
		
		System.out.println(domesticCars[0]);
		System.out.println(domesticCars[1]);
		System.out.println(domesticCars[2]);
		System.out.println(domesticCars[3]);
				
		domesticCars[0] = "Mustang";		//writing over index 0 to change it to Mustang
		System.out.println(domesticCars[0]);
		System.out.println(domesticCars[1]);
		System.out.println(domesticCars[2]);
		System.out.println(domesticCars[3]);
		
		String [] foreignCars = new String[3];	//indicating how big the array will be
		foreignCars[0] = "BMW";
		foreignCars[1] = "Mercedes";
		foreignCars[2] = "Saab";
		
		System.out.println(foreignCars[0]);
		System.out.println(foreignCars[1]);
		System.out.println(foreignCars[2]);
		
		for (int i = 0; i < domesticCars.length; i++) {
			System.out.println(domesticCars[i]);
			
		}
		
	}

}
