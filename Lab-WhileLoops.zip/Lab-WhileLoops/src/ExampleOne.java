
public class ExampleOne {
	public static void main(String[] args) {
		boolean on = true;
		
		while(on) {
			System.out.println("Inside of the While Loop");
//			on = false;
		}
	}
}
