package main;

import java.util.ArrayList; 

public class ArrayList {
	
	public static void main(String[] args) {
		
		/*
		 * ArrayList is a resizable array.
		 * 		Elements can be added and removed after compilation phase.
		 * 		Only store reference data types.
		 */
		
		ArrayList<String> food = new ArrayList<String>();	//I don't know why it says ArrayList is not a generic
		
		food.add("pizza");
		food.add("hamburger");
		food.add("hot dog");
		
		food.set(0, "sushi");
		food.remove(2);
		food.clear();
		
		for(int i =0; i < food.size(); i++) {
			System.out.println(food.get(i));
		}
		
		
	}

}
