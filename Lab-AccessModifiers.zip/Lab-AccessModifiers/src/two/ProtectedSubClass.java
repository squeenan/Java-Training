package two;

import one.ProtectedClass;

public class ProtectedSubClass extends ProtectedClass {

}
