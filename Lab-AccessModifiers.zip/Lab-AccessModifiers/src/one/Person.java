package one;

public class Person {
	public int age;
	public String sex;
	public double weight;
	public int height;
				
}
