package one;

import two.ProtectedSubClass;

public class AccessModifiers {
	public static void main(String[] args) {
		//access class methods here
		Person adam = new Person();
		adam.age = 15;
		adam.height = 72;
		adam.sex = "male";
		adam.weight = 165;
				
		System.out.println(adam.age);
		System.out.println(adam.height + " inches");
		System.out.println(adam.sex);
		System.out.println(adam.weight + " pounds");
		
		ProtectedSubClass psc = new ProtectedSubClass();
		psc.printID();
	}
}
