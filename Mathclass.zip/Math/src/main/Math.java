package main;

public class Math {

	public static void main(String[] args) {
		double x = 3.14;
		double y = 10;
		
		double z = Math.max(x, y);		//finds highest value
		System.out.println(z);
		
		Math.min(x,y);					//finds lowest value
		System.out.println(z);
		
		Math.abs(y);					//displays absolute value
		System.out.println(z);

		Math.sqrt(y);					//takes the square root of value
		System.out.println(z);

		Math.round(x);					//rounds value
		System.out.println(z);

		Math.ceiling(x);				//rounds value up
		System.out.println(z);

		Math.floor(x);					//rounds value down
		System.out.println(z);

		
	}
}
