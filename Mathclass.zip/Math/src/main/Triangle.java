package main;

import java.util.Scanner;

public class Triangle {

	public static void main(String[] args) {
		
		double x;
		double y;
		double z;
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter side x: ");
		x = scan.nextDouble();
		
		System.out.println("Enter side y: ");
		x = scan.nextDouble();
		
		z = Math.sqrt((x*x) + (y * y));			//finds hypotenuse of triangle
		System.out.println("The hypotenuse is: " +z);
		
		scan.close();
		
		
	}
}
