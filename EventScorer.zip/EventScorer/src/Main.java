import java.util.ArrayList;
import java.util.List;

import manager.ScoreManager;
import pojo.Event;
import pojo.Group;
import pojo.Member;

public class Main {
	
	public static void main(String[] args) {
		
		/*
		 *  1. Configure Group and Member
		 *  	A * A1|A2|A3 # B * B1|B2|B3
		 */  
		Group g1 = new Group("A");
		g1.addMember(new Member("A1"));
		g1.addMember(new Member("A2"));
		g1.addMember(new Member("A3"));
		Group g2 = new Group("B");
		g2.addMember(new Member("B1"));
		g2.addMember(new Member("B2"));
		g2.addMember(new Member("B3"));
		
		 /*  2. Add scores of each member for a given event
		 *  	EVENT 1>A1*90|A2*56|...
		 *  	EVENT 2>A1*78|A2*45|...
		 * 	    EVENT 3>A1*45|A2*66|...
		 */  	
		Event e1 = new Event("Event 1");
		e1.addScore(new Member("A1"), 96);
		e1.addScore(new Member("A2"), 85);
		e1.addScore(new Member("A3"), 94);
		e1.addScore(new Member("B1"), 75);
		e1.addScore(new Member("B2"), 82);
		e1.addScore(new Member("B3"), 69);
		Event e2 = new Event("Event 2");
		e2.addScore(new Member("A1"), 87);
		e2.addScore(new Member("A2"), 96);
		e2.addScore(new Member("A3"), 73);
		e2.addScore(new Member("B1"), 84);
		e2.addScore(new Member("B2"), 93);
		e2.addScore(new Member("B3"), 71);
		
		
		
		 /*  3. Show the groups with scores descending
		 *  	A - 89
		 *  	B - 86
		 *  	C - 78  
		 */
		ScoreManager manager = new ScoreManager();
		manager.addScores(e1);
		manager.addScores(e2);
		
		List<Group> groups = new ArrayList<Group>();
		groups.add(g1);
		groups.add(g2);
		
		manager.getScoresByGroup(groups, true);
		
		System.out.println(groups);
		for(Group g : groups) {
			System.out.println(g.getName() + " : " +g.getScore());
		}
	}
	
}
