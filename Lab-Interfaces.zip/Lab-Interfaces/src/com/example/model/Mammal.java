package com.example.model;

public class Mammal {

}
