

//class b is a composite of class a
public class ClassB {

	//declares ClassA as an instance variable
	ClassA classA = new ClassA();
	
	public static void main(String[] args) {
		
		//instantiate a new ClassB object
		ClassB b = new ClassB();
		b.classA.setName("Joseph 'Mr. Revature' Highe");
		
		System.out.println(b.classA.getName());
		
	}
}
