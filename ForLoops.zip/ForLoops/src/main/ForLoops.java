package main;

public class ForLoops {

	public static void main(String[] args) {

		// For Loops execute a block of code a limited amount of times
		
		for (int i = 0; i <= 5; i++) {
			System.out.println(i);
			
		}
		
		for (int i = 10; i >= 0; i--) {
			System.out.println(i);
		}
		System.out.println("Happy New Year!!");
	}

}
